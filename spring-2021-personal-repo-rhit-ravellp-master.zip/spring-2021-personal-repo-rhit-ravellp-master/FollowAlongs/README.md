For each follow along you should:
1. Create a folder with the name of the follow along (i.e. "HelloWorld" )
2. Copy the code from the public template repo (may need to clone first to have a local version to copy)
3. Commit your work as you make progress
4. Be sure to leave a commit message when the project is done, i.e. "HelloWorld COMPLETE"