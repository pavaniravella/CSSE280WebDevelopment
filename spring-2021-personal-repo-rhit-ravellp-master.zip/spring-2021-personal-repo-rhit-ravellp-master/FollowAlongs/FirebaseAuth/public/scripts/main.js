var rhit = rhit || {};

rhit.main = function () {
	console.log("Ready");

	firebase.auth().onAuthStateChanged((user) => {
		if (user) {
			// User is signed in.
			var displayName = user.displayName;
			var email = user.email;
			var photoURL = user.photoURL;
			var isAnonymous = user.isAnonymous;
			var phoneNumber = user.phoneNumber;
			var uid = user.uid;
			console.log("Signed in", uid);
			console.log('displayName :>> ', displayName);
			console.log('email :>> ', email);
			console.log('photoURL :>> ', photoURL);
			console.log('isAnonymous :>> ', isAnonymous);
			console.log('phoneNumber :>> ', phoneNumber);
			console.log('uid :>> ', uid);
		} else {
			// User is signed out.
			// ...
			console.log("No user is signed in.");
		}
	});

	const inputEmailEl = document.querySelector("#inputEmail");
	const inputPasswordEl = document.querySelector("#inputPassword");

	document.querySelector("#createAccountButton").onclick = (event) => {
		console.log(`Create account for email: ${inputEmailEl.value}  password: ${inputPasswordEl.value}`);
		firebase.auth().createUserWithEmailAndPassword(inputEmailEl.value, inputPasswordEl.value).catch(function (error) {
			var errorCode = error.code;
			var errorMessage = error.message;
			console.log("Create user error", errorCode, errorMessage);
		});
	};

	document.querySelector("#logInButton").onclick = (event) => {
		console.log(`Log in to existing account for email: ${inputEmailEl.value}  password: ${inputPasswordEl.value}`);
		firebase.auth().signInWithEmailAndPassword(inputEmailEl.value, inputPasswordEl.value).catch(function (error) {
			var errorCode = error.code;
			var errorMessage = error.message;
			console.log("Log in existing user error", errorCode, errorMessage);
		});
	};

	document.querySelector("#anonymousAuthButton").onclick = (event) => {
		console.log(`Log in via Anonymous auth`);

		firebase.auth().signInAnonymously().catch(function (error) {
			// Handle Errors here.
			var errorCode = error.code;
			var errorMessage = error.message;
			console.log("Log in existing user error", errorCode, errorMessage);
		});
	};

	document.querySelector("#signOutButton").onclick = (event) => {
		console.log("Sign Out called");
		firebase.auth().signOut().then(function () {
			// Sign-out successful.
		}).catch(function (error) {
			// An error happened.
		});
	};

	rhit.startFirebaseAuthUi();
};

rhit.startFirebaseAuthUi = () => {
	// Initialize the FirebaseUI Widget using Firebase.
	var ui = new firebaseui.auth.AuthUI(firebase.auth());
	ui.start('#firebaseui-auth-container', {
		signInSuccessUrl: '/',
		signInOptions: [
			firebase.auth.GoogleAuthProvider.PROVIDER_ID,
			firebase.auth.EmailAuthProvider.PROVIDER_ID,
			firebase.auth.PhoneAuthProvider.PROVIDER_ID,
			firebaseui.auth.AnonymousAuthProvider.PROVIDER_ID,
		],
		// Other config options...
	});

	// var uiConfig = {
	// 	//signInSuccessUrl: '/',
	// 	signInOptions: [
	// 		// Leave the lines as is for the providers you want to offer your users.
	// 		// firebase.auth.GoogleAuthProvider.PROVIDER_ID,
	// 		firebase.auth.EmailAuthProvider.PROVIDER_ID,
	// 		// firebase.auth.PhoneAuthProvider.PROVIDER_ID,
	// 		// firebaseui.auth.AnonymousAuthProvider.PROVIDER_ID
	// 	],
	// };

	// // Initialize the FirebaseUI Widget using Firebase.
	// var ui = new firebaseui.auth.AuthUI(firebase.auth());
	// ui.start('#firebaseui-auth-container', uiConfig);
}

rhit.main();