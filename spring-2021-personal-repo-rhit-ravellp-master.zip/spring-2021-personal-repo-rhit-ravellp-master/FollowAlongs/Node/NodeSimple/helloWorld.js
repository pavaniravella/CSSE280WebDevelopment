// console.log("Hello CSSE280!")
let counter = 0;
setInterval( () => {
    counter++;
    console.log( "counter: ", counter );
}, 500 );
