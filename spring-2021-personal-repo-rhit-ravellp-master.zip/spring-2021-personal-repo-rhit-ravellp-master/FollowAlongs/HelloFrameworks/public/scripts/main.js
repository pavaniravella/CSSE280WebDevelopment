var rhit = rhit || {};
rhit.counter = 0;

rhit.main = function () {
	console.log("Ready");
	// $("#counterButtons button").click((event) => {
	// 	const changeAmount = $(event.target).data("amount");
	// 	const isMultiplication = $(event.target).data("isMultiplication");
	// 	console.log(`amount = ${changeAmount}  isMultiplication = ${isMultiplication}`);
	// 	rhit.updateCounter(changeAmount, isMultiplication);
	// });

	let buttons = document.querySelectorAll("#counterButtons button");
	buttons.forEach((button) => {
		button.onclick = (event) => {
			const changeAmount = parseInt(button.dataset.amount);
			const isMultiplication = button.dataset.isMultiplication == "true";
			console.log(`amount = ${changeAmount}  isMultiplication = ${isMultiplication}`);
			rhit.updateCounter(changeAmount, isMultiplication);
		}
	});
};

rhit.updateCounter = (changeAmount, isMultiplication) => {
	if (isMultiplication) {
		rhit.counter *= changeAmount;
	} else {
		rhit.counter += changeAmount;
	}
	//document.querySelector("#counterText").innerHTML = `Count = ${rhit.counter}`;
	$("#counterText").html(`Count = ${rhit.counter}`);
};

rhit.main();
