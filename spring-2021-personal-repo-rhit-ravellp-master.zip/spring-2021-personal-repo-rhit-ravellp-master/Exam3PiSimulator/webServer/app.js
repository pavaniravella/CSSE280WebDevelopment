var express = require("express");
var app = express();

var firstOpeningServer= true; 
let data = {};

const fs = require("fs");
const serverSideStorage = "../data/db.json";

fs.readFile(serverSideStorage, function (err, buf) {
    if (err) {
        console.log("error: ", err);
    } else {
        data = JSON.parse(buf.toString());
    }
    console.log("Data read from file.");
});

function saveToServer(data) {
    fs.writeFile(serverSideStorage, JSON.stringify(data), function (err, buf) {
        if (err) {
            console.log("error: ", err);
        } else {
            console.log("Data saved successfully!");
        }
    })
}

function getRandomInt(max) {
    return Math.floor(Math.random() * max);
  }


app.use('/', express.static("public"));

//middleware - updated to avoid the body-parser deprecation warning.
app.use('/api/', express.json());

// TODO: Create your backend API here:
/**
 * Read button	- Gets the state of the fake pushbutton (0 or 1)
 *   method:                    GET
 *   path:                      /api/readbutton
 *   expected request body:     none
 *   side effects:              none (the pushbutton is always random)
 *   response:                  {"button": 0} or {"button": 1}
 */

 app.get( "/api/readbutton", ( req, res ) => {
    data["button"] = getRandomInt(2);
    saveToServer(data)
    res.send( { "button": data["button"]} );
    res.end();
});
/**
 * Set LED - Sets the state of 1 LED
 *   method:                    PUT
 *   path:                      /api/setled/:color/:state
 *   expected request body:     none
 *   side effects:              saves the state for this LED into db.json
 *                              prints to the console the LED states
 *   response:                  {"leds": {"red": 1, "yellow": 0, "green": 0}}
*/

app.put( "/api/setled/:color/:state", ( req, res ) => {
    // console.log("first time opening server: " + firstOpeningServer)
    // if(firstOpeningServer==true){
    //     data["red"] = 0;
    //     data["yellow"] = 0;
    //     data["green"] = 0;
    //     saveToServer(data);
    //     firstOpeningServer=false;
    // }
   // console.log("data before " + data); 
    var color = req.params.color; 
    var value = req.params.state
    data[ color ] = parseInt(value)

    saveToServer( data );
    res.send({"leds": {"red": data["red"], "yellow": data["yellow"], "green": data["green"]}})
    //res.send( {"leds": {"red": data[red], "yellow": data[yellow], "green":data[green]}});
    console.log("LED States:")
    console.log("\tRed: " + data["red"]);
    console.log("\tYellow: " + data["yellow"]);
    console.log("\tGreen: " + data["green"]);
    res.end();
});
/**
 *  Set servos - Set all three servo angles using a POST, body is a JSON array with 3 numbers.
 *    method:                    POST
 *    path:                      /api/setservos
 *    expected request body:     JSON object, for example {"angles": [-90, 90, 0]}
 *   side effects:               saves the state of the servos into db.json
 *                               prints to the console the servo states
 *    response:                  {"servos": [-90, 90, 0]}
 */
 app.post( "/api/setservos", ( req, res ) => {
    // console.log("setting servos")
   
    var obj = req.body; 
   
    var j = obj.angles;
 
    data["servos"] = j; 

   saveToServer( data );
   console.log("Servo States:")
   console.log("\t Servo join 1: " + j[0])
   console.log("\t Servo join 2: " + j[1])
   console.log("\t Servo join 3: " +j[2])
  res.send( { "servos": data["servos"]});
});

/**
 *  Get Status - Get the state of all fake physical components.
 *    method:                    GET
 *    path:                      /api/getstatus
 *    expected request body:     none
 *    side effects:              none
 *    response:                  {"button": 0, "leds": {"red": 1, "yellow": 1, "green": 0},
 *                                "servos": [0, 45, 0]}
 */

 app.get( "/api/getstatus", ( req, res ) => {
    res.send( {"button": data["button"], 
                "leds": {"red":data["red"], "yellow": data["yellow"], "green": data["green"]},
                                    "servos": data["servos"]} );
    res.end();
});

app.listen(3000);