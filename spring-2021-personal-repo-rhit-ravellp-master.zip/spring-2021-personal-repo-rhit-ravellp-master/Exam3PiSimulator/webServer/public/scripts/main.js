
const apiURL = "http://localhost:3000/api/"
var selectedId = "";
var editEntryMode = false;

var counter = 0;

function main() {
	console.log("Ready");
	loadValues();
	document.querySelector("#getStatusBtn").onclick = (event) => {
		loadValues();
	};
	document.querySelector("#updateStatusBtn").onclick = (event) => {
		updateValues();
	};




}


function loadValues() {

	fetch(apiURL + "getstatus")
		.then(response => response.json())
		.then(data => {
			var colors = data["leds"];
			
			if (data["button"] == 1)
				document.querySelector("#Pushbutton").innerHTML = "high";

			if (data["button"] == 0)
				document.querySelector("#Pushbutton").innerHTML = "low";
			if (colors.green == 1)
				document.querySelector("#green").innerHTML = "on";

			if (colors.green == 0)
				document.querySelector("#green").innerHTML = "off";
			if (colors.yellow == 1)
				document.querySelector("#yellow").innerHTML = "on";
			if (colors.yellow == 0)
				document.querySelector("#yellow").innerHTML = "off";
			if (colors.red == 1)
				document.querySelector("#red").innerHTML = "on";
			if (colors.red == 0)
				document.querySelector("#red").innerHTML = "off";
			console.log(data["leds"])
			
			document.querySelector("#Joint1").innerHTML=data["servos"][0];
			document.querySelector("#Joint2").innerHTML=data["servos"][1];
			document.querySelector("#Joint3").innerHTML=data["servos"][2];
		}
		);
}




function updateValues() {
	var red = document.querySelector("#redInput");
	var yellow = document.querySelector("#yellowInput");
	var green = document.querySelector("#greenInput");
	var j1 =document.querySelector("#jointInput1");
	var j2 =document.querySelector("#jointInput2");
	var j3 =document.querySelector("#jointInput3");
	fetch( apiURL + "setled/red/" + red.value, {
		"method": "PUT",
		"headers": { "Content-Type": "application/json" },
		"body": JSON.stringify( { "red": red.value } )
	}).catch( err => console.log( err ) );

	fetch( apiURL + "setled/green/" + green.value, {
		"method": "PUT",
		"headers": { "Content-Type": "application/json" },
		"body": JSON.stringify( { "green": green.value } )
	}).catch( err => console.log( err ) );

	fetch( apiURL + "setled/yellow/" + yellow.value, {
		"method": "PUT",
		"headers": { "Content-Type": "application/json" },
		"body": JSON.stringify( { "yellow": yellow.value } )
	}).catch( err => console.log( err ) );

	fetch( apiURL + "readbutton" )
    .then( response => response.json() )
    .then( data => {
		document.querySelector("#Pushbutton").innerHTML= "" + data["button"]
    });

var jsonObj = {"angles": [parseInt(j1.value), parseInt(j2.value), parseInt(j3.value)]}
	console.log(jsonObj)
	 fetch( apiURL + "setservos", {
 	method: "POST",
	 	headers: { "Content-Type": 'application/json'},
		body: JSON.stringify( jsonObj )
	   } )
	 	.then( stuff => {
		 
	 	})
		.catch(  (err) => {
	 	  console.log(err);
	 	});
}





main();