

// document.getElementById('contact-form').addEventListener('submit', function(event) {
// 	event.preventDefault();
// 	// generate a five digit number for the contact_number variable
// 	this.contact_number.value = Math.random() * 100000 | 0;
// 	// these IDs from the previous steps
// 	function sendEmail() {
		Email.send({
			 Host: "smtp.gmail.com",
			 Username: "digitalvaccinereminder@gmail.com",
			  Password: "AveryPavani",
			
			From: "digitalvaccinereminder@gmail.com",
			To: 'digitalvaccinereminder@gmail.com ',
			Subject: "hi",
			Body: "hi bobby"
		})
			.then(function (message) {
				alert("mail sent successfully")
			});
console.log("hi")
// /**
//  * @fileoverview
//  * Provides the JavaScript interactions for all pages.
//  *
//  * @author 
//  * PUT_YOUR_NAME_HERE
//  */

// /** namespace. */
// var rhit = rhit || {};

// /** globals */
// rhit.variableName = "";

// /** function and class syntax examples */
// rhit.functionName = function () {
// 	/** function body */
// };

// rhit.ClassName = class {
// 	constructor() {

// 	}

// 	methodName() {

// 	}
// }

// /* Main */
// /** function and class syntax examples */
// rhit.main = function () {
// 	console.log("Ready");
// };

// rhit.main();
