var empRef=firebase.database().ref("employees");

window.onload = function (){
	initApp();
	displayEmpData();
};

function initApp(){
	document.getElementById('add_emp').addEventListener('click', addNewEmp, false);
}

function addEmp(){
	var name = document.getElementById('name').value  ;
	var email = document.getElementById('email').value  ;
	var phone = document.getElementById('phone').value  ;
	var address= document.getElementById('address').value  ;
	var timeStamp = new Date().getTime()
	var empID = 'EMP_' + tempStamp; 

	empRef.child(empRef).set({
		name: name, 
		phone : phone, 
		address : address,
		
		emp_id : empID 
	})
	$('#name').val('')
	$('#phone').val('')
	$('#address').val('')
	$('#emp_id').val('')
}