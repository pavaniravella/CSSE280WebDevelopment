var rhit = rhit || {};
var first = 0;
var second = 0;
var third = 0;
var fourth = 0;
var firstCount = 0;
var secondCount = 0;
var thirdCount = 0;
var fourthCount = 0;
var startingTicket = 0;
var remainingBudget;
rhit.WaterParkController = class {

	constructor() {

		const startingTicketsInput = document.querySelector("#startingTicketsInput");
		const updateBtn = document.querySelector("#updateButton");
		const btn1 = document.querySelector("#option1Button");
		const btn2 = document.querySelector("#option2Button");
		const btn3 = document.querySelector("#option3Button");
		const btn4 = document.querySelector("#option4Button");
		const resetBtn = document.querySelector("#resetButton");

		//setting the values 
		first = btn1.getAttribute("data-cost");
		second = btn2.getAttribute("data-cost");
		third = btn3.getAttribute("data-cost");
		fourth = btn4.getAttribute("data-cost");
		startingTicket = startingTicketsInput.value;
		console.log("starting ticket : " + startingTicket);
		//console.log("FIrst" + first + " second " + second + " third " + third + " fourth " + fourth);
		// Optionally you can use an array of button elements.

		const buttons = [btn1, btn2, btn3, btn4];
		remainingBudget = 200;
		// TODO: Add code to the constructor as needed
		updateBtn.onclick = (event) => {

			this.updateStartingBalance();

			//this.updateView();
		}
		btn1.onclick = (event) => {
			console.log("I am in big drop button")
			firstCount = firstCount + 1;
			console.log("first count = " + firstCount)
			this.updateView();
		}
		btn2.onclick = (event) => {
			console.log("I am in tubes button")
			secondCount = secondCount + 1;
			console.log("second count = " + secondCount);
			this.updateView();
		}
		btn3.onclick = (event) => {
			console.log("I am in pizza button")
			thirdCount = thirdCount + 1;
			console.log("third count = " + thirdCount);

			this.updateView();
		}
		btn4.onclick = (event) => {
			console.log("I am in pretezel button")
			fourthCount = fourthCount + 1;
			console.log("fourth counth = " + fourthCount)
			this.updateView();
		}
		resetBtn.onclick = (event) => {
			this.resetAllCounters();
			 this.updateView();
		}



		console.log("I am in constructor after");
		// Note: You are REQUIRED to get the starting ticket value and the
		// costs for each activity from the HTML using tricks like .value on an element
		// or .dataset on elements.  You may NOT hardcode things like...
		//   this.startingTickets = 200;
		//   this.costs = [40, 15, 100, 20];
		// The above hardcode would lose points. You must show you can get those values
		// from the HTML.  They are already present in the given html, use JavaScript to
		// read those values from the appropriate HTML elements.



		//this.updateView();
	}

	// TODO: Add methods as needed

	updateStartingBalance() {
		const counterDisplay1 = document.querySelector("#option1Counter");
		const counterDisplay2 = document.querySelector("#option2Counter");
		const counterDisplay3 = document.querySelector("#option3Counter");
		const counterDisplay4 = document.querySelector("#option4Counter");
		const ticketsRemainingDisplay = document.getElementById("ticketsRemaining");
		const startingTicketsDisplay2 = document.getElementById("startingTicketsInput");
		var startingTicketsNum2 = startingTicketsDisplay2.value; 
		var ticketsRemaining2 = ticketsRemainingDisplay.value; 
		console.log("starting tickets update : " + startingTicketsNum2);
		console.log("tickets remaining update : " + ticketsRemaining2);
		console.log("remaining budget: " + remainingBudget)
		if(remainingBudget<=0)
		{
			var food = Number(startingTicketsNum2) + Number(remainingBudget)
			console.log("food " + food)
			ticketsRemainingDisplay.innerHTML = food;
			remainingBudget=food;
			console.log("remaining budget food: " + remainingBudget)
			return;
		}
		var writeDisplay  = startingTicketsNum2 + remainingBudget; 
		console.log("write display: " + writeDisplay);
		ticketsRemainingDisplay.innerHTML = writeDisplay;
		remainingBudget = writeDisplay;
		console.log("remaining budget: " + remainingBudget)
	
	}
	updateView() {

		 console.log("i am in the updateview2")
	
		const counterDisplay1 = document.querySelector("#option1Counter");
		const counterDisplay2 = document.querySelector("#option2Counter");
		const counterDisplay3 = document.querySelector("#option3Counter");
		const counterDisplay4 = document.querySelector("#option4Counter");
		const ticketsRemainingDisplay = document.querySelector("#ticketsRemaining");

		// Optionally you can use an array of text output elements.
		const counterDisplays = [counterDisplay1, counterDisplay2, counterDisplay3, counterDisplay4];

		// TODO: Add code to updateView as needed
		var remaining = parseInt(ticketsRemainingDisplay.value); 
		console.log("ticket remaining value : " + ticketsRemainingDisplay.value);
		var c1 = document.getElementById("option1Counter").value;
	
	
	
		var takenBudget = (firstCount * first) + (secondCount * second) + (thirdCount * third) + (fourthCount* fourth);
		
		console.log("remaining budget: " + remainingBudget);
		console.log("starting budget " + startingTicket);
		remainingBudget = startingTicket - takenBudget; 
		console.log("remaining budget2: " + remainingBudget);
		if(remainingBudget>=0){
			ticketsRemainingDisplay.innerHTML = remainingBudget; //startingTicket- takenBudget;
			counterDisplay1.innerHTML= firstCount;
		counterDisplay2.innerHTML= secondCount;
		counterDisplay3.innerHTML= thirdCount;
		counterDisplay4.innerHTML= fourthCount;
		}
		else{
			return; 
		}
		

	}

	resetAllCounters() {

		firstCount = 0;
		secondCount = 0;
		thirdCount = 0;
		fourthCount = 0;
		startingTicket = 200;
		remainingBudget = 200;
		console.log("i am in reset");
		const ticketsRemainingDisplay = document.querySelector("#ticketsRemaining");
		const startingTicketsInput = document.querySelector("#startingTicketsInput");
		var beginning = 200;
		var ending = 200;
		startingTicket = 200;
		const counterDisplay1 = document.querySelector("#option1Counter");
		const counterDisplay2 = document.querySelector("#option2Counter");
		const counterDisplay3 = document.querySelector("#option3Counter");
		const counterDisplay4 = document.querySelector("#option4Counter");
		counterDisplay1.innerHTML = firstCount;
		counterDisplay2.innerHTML = secondCount;
		counterDisplay3.innerHTML = thirdCount;
		counterDisplay4.innerHTML = fourthCount;
		//remainingBudget = 0; 
		//takenBudget = 0; 
		ticketsRemainingDisplay.innerHTML = beginning;
		startingTicketsInput.innerHTML = startingTicket;
		//updateView();

	}
}

/* Main */
rhit.main = function () {
	console.log("Ready");
	new rhit.WaterParkController();
};

rhit.main();