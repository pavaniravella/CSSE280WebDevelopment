# CSSE280-Personal-Repo
This serves as the starting repo for individual student work in CSSE280.

You should use the two folders, FollowAlongs and Homeworks, in order to organize your work and regularly commit as you make progress during the quarter. 

* Be sure to leave a commit message when your work on a particular project is completed, i.e. "HelloWorld COMPLETE"
