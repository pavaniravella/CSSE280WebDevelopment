

var rhit = rhit || {};

rhit.FB_COLLECTION_PHOTOS = "Photos";
rhit.FB_KEY_URL = "URL";
rhit.FB_KEY_CAPTION = "caption";
rhit.FB_KEY_LAST_TOUCHED = "lastTouched";
rhit.FB_KEY_AUTHOR = "author";
rhit.fbPhotosManager = null;
rhit.fbSinglePhotoManager = null;
rhit.fbAuthManager = null;

// From StackOverflow from Dr. Fisher
function htmlToElement(html) {
	var template = document.createElement('template');
	html = html.trim();
	template.innerHTML = html;
	return template.content.firstChild;
}

rhit.LoginPageController = class {
	constructor() {
		console.log("Login controller page made");
		document.querySelector("#roseFireButton").onclick = (event) => {
			rhit.fbAuthManager.signIn();
		}

	}
}

rhit.FbAuthManager = class {
	constructor() {
		this._user = null;
		console.log("Made Auth Manager");
	}
	beginListening(changeListener) {
		firebase.auth().onAuthStateChanged((user) => {
			this._user = user;
			changeListener();
			if (user) {
				const uid = user.uid;
			}
		});
	}
	signIn() {
		console.log("Sign in");

		Rosefire.signIn("fae5da93-4b71-465c-b5fc-565841459a26", (err, rfUser) => {
			if (err) {
			  console.log("Rosefire error!", err);
			  return;
			}
			console.log("Rosefire success!", rfUser);
			
			// TODO: Use the rfUser.token with your server.

			firebase.auth().signInWithCustomToken(rfUser.token).catch((error) => {
				const errorCode = error.code;
				const errorMessage = error.message;
				if (errorCode === 'auth/invalid-custom-token'){
					alert('The token you provided is not valid.')
				} else {
					console.error("Custom auth error ", errorCode, errorMessage);
				}	
			});
		  });
		  

	}
	signOut() {
		firebase.auth().signOut().then(() => {
			// Sign-out successful.
			console.log("Sign-out successful.");
		}).catch((error) => {
			// An error happened.
			console.log("Sign out, an error happened.");
		});
	}
	get isSignedIn() {
		return !!this._user;
	}
	get uid() {
		return this._user.uid;
	}
}

rhit.ListPageController = class {
	constructor() {
		console.log("created ListPageController");

		document.querySelector("#menuShowAllPhotos").onclick = (event) => {
			console.log("show all photos");

			window.location.href = "/list.html";
		}

		document.querySelector("#menuShowMyPhotos").onclick = (event) => {
			console.log("show my photos");

			window.location.href = `/list.html?uid=${rhit.fbAuthManager.uid}`;

		}

		document.querySelector("#menuSignOut").onclick = (event) => {
			console.log("sign out");
			rhit.fbAuthManager.signOut();
		}

		document.querySelector("#submitAddPhoto").onclick = (event) => {
			console.log("Clicked");
			const URL = document.querySelector("#inputPhoto").value;
			const caption = document.querySelector("#inputCaption").value;
			rhit.fbPhotosManager.add(URL, caption);
		}

		$('#addPhotoDialog').on('show.bs.modal', (event) => {
			document.querySelector("#inputPhoto").value = "";
			document.querySelector("#inputCaption").value = "";
		  })

		$('#addPhotoDialog').on('shown.bs.modal', (event) => {
			document.querySelector("#inputPhoto").focus();
		})

		rhit.fbPhotosManager.beginListening(this.updateList.bind(this));

	}

	_createPin(photo){ // id="HXVidTpNvdWesDXMH0Bu"   <- in first div
		return htmlToElement(`
		<div class="pin" id="${photo.id}"> 
			<img src="${photo.URL}" alt="${photo.caption}">
			<p class="caption">${photo.caption}</p>
		</div>`)
	}

	updateList() {

		const newList = htmlToElement('<div id="photoListContainer"></div>');

		for(let i = 0; i < rhit.fbPhotosManager.length; i++){
			const photo = rhit.fbPhotosManager.getPhotoAtIndex(i);
			const newPin = this._createPin(photo)
			newPin.onclick = (event) => {
				window.location.href = `/pic.html?id=${photo.id}`;

			}
			newList.appendChild(newPin);
		}

		const oldList = document.querySelector("#photoListContainer");
		oldList.removeAttribute("id");
		oldList.hidden = true;
		oldList.parentElement.appendChild(newList);
	}
}

rhit.Photo = class {
	constructor(id, URL, caption){
		this.id = id;
		this.URL = URL;
		this.caption = caption;
	}
}

rhit.FbPhotosManager = class { 
	constructor(uid) {
	  console.log("created FbPhotosManager");
	  this._documentSnapshots = [];
	  this._uid = uid;
	  this._ref = firebase.firestore().collection(rhit.FB_COLLECTION_PHOTOS);
	  this._unsubscribe = null;
	}

	add(URL, caption) {    
		console.log(`add URL ${URL}`);
		console.log(`add caption ${caption}`);

		// Add a new document with a generated id.
		this._ref.add({
			[rhit.FB_KEY_URL]: URL,
			[rhit.FB_KEY_CAPTION]: caption,
			[rhit.FB_KEY_AUTHOR]: rhit.fbAuthManager.uid,
			[rhit.FB_KEY_LAST_TOUCHED]: firebase.firestore.Timestamp.now(),
		})
		.then((docRef) => {
			console.log("Document written with ID: ", docRef.id);
		})
		.catch((error) => {
			console.error("Error adding document: ", error);
		});
	}

	beginListening(changeListener) {   

		let query = this._ref.orderBy(rhit.FB_KEY_LAST_TOUCHED, 'desc').limit(50);
		if(this._uid){
			query = query.where(rhit.FB_KEY_AUTHOR, "==", this._uid);
		}

		this._unsubscribe = query.onSnapshot((querySnapshot) => {
			console.log("Update!");
			this._documentSnapshots = querySnapshot.docs;
			
			changeListener();
    	});
	 }
	stopListening() {    
		this._unsubscribe;
	}
	get length() {    
		return this._documentSnapshots.length;
	}
	getPhotoAtIndex(index) {  
		const docSnapshot = this._documentSnapshots[index];
		const photo = new rhit.Photo(
			docSnapshot.id,
			docSnapshot.get(rhit.FB_KEY_URL),
			docSnapshot.get(rhit.FB_KEY_CAPTION),
		);
		return photo;
	}
}

rhit.DetailPageController = class {
	constructor() {
		console.log("Made");

		document.querySelector("#menuSignOut").onclick = (event) => {
			console.log("sign out");
			rhit.fbAuthManager.signOut();
		}


		document.querySelector("#submitEditPhoto").onclick = (event) => {
			console.log("Clicked");
			const caption = document.querySelector("#inputCaption").value;
			rhit.fbSinglePhotoManager.update(caption);
		}

		// $('#editPhotoDialog').on('show.bs.modal', (event) => {
		// 	document.querySelector("#inputPhoto").value = rhit.fbSinglePhotoManager.URL;
		// 	document.querySelector("#inputCaption").value = rhit.fbSinglePhotoManager.caption;
		//   })

		$('#editPhotoDialog').on('shown.bs.modal', (event) => {
			document.querySelector("#inputCaption").focus();
		})

		document.querySelector("#submitDeletePhoto").onclick = (event) => {
			console.log("Clicked Delete");
			rhit.fbSinglePhotoManager.delete().then(() => {
				console.log("Document successfully deleted!");
				window.location.href = "/";
			}).catch((error) => {
				console.error("Error removing document: ", error);
			});
		}

		rhit.fbSinglePhotoManager.beginListening(this.updateView.bind(this));
	}
	updateView() {  
		document.querySelector("#URL").src = rhit.fbSinglePhotoManager.URL;
		document.querySelector("#URL").alt = rhit.fbSinglePhotoManager.URL;
		document.querySelector("#caption").innerHTML = rhit.fbSinglePhotoManager.caption;

		if(rhit.fbSinglePhotoManager.author == rhit.fbAuthManager.uid){
			document.querySelector("#menuEdit").style.display = "flex";
			document.querySelector("#menuDelete").style.display = "flex";

		}

	}
}

rhit.FbSinglePhotoManager = class {
	constructor(photoId) {
	  this._documentSnapshot = {};
	  this._unsubscribe = null;
	  this._ref = firebase.firestore().collection(rhit.FB_COLLECTION_PHOTOS).doc(photoId);
	  console.log("Listen");
	}

	beginListening(changeListener) {
		this._unsubscribe = this._ref.onSnapshot((doc) => {
			if (doc.exists) {
				console.log("Document data:", doc.data());
				this._documentSnapshot = doc;
				changeListener();
			} else {
				// doc.data() will be undefined in this case
				console.log("No such document!");
			}
		});
	}
	stopListening() {
	  this._unsubscribe();
	}
	update(caption) {
		console.log("update");
		this._ref.update({
			[rhit.FB_KEY_CAPTION]: caption,
			[rhit.FB_KEY_LAST_TOUCHED]: firebase.firestore.Timestamp.now(),
		})
		.then(() => {
			console.log("Document updated!");
		})
		.catch((error) => {
			console.error("Error adding document: ", error);
		});

	}
	delete() {
		return this._ref.delete();
	}

	get URL(){
		return this._documentSnapshot.get(rhit.FB_KEY_URL);
	}

	get caption(){
		return this._documentSnapshot.get(rhit.FB_KEY_CAPTION);
	}

	get author(){
		return this._documentSnapshot.get(rhit.FB_KEY_AUTHOR);

	}
}

rhit.startFirebase = function(){
	// FirebaseUI config.
	var uiConfig = {
        signInSuccessUrl: '/',
        signInOptions: [
          // Leave the lines as is for the providers you want to offer your users.
          firebase.auth.GoogleAuthProvider.PROVIDER_ID,
          firebase.auth.EmailAuthProvider.PROVIDER_ID,
          firebase.auth.PhoneAuthProvider.PROVIDER_ID,
          firebaseui.auth.AnonymousAuthProvider.PROVIDER_ID
        ],
      };

      // Initialize the FirebaseUI Widget using Firebase.
      const ui = new firebaseui.auth.AuthUI(firebase.auth());
      // The start method will wait until the DOM is loaded.
      ui.start('#firebaseui-auth-container', uiConfig);
}   

rhit.initFireAuth = function(){
	firebase.auth().onAuthStateChanged((user) => {
		if (user) {
		  const uid = user.uid;
		  const displayName = user.displayName;
		  const email = user.email;
		  const isAnonymous = user.isAnonymous;
		  const phoneNumber = user.phoneNumber;
		  const photoURL = user.photoURL;
		  // ...

		  console.log("The user is signed in ", uid);
		  console.log('displayName :>> ', displayName);
		  console.log('email :>> ', email);
		  console.log('isAnonymous :>> ', isAnonymous);
		  console.log('phoneNumber :>> ', phoneNumber);
		  console.log('photoUrl :>> ', photoURL);
		} else {
			console.log("No user signed in!");
		  // User is signed out
		  // ...
		}
	});
}

rhit.main = function () {

	rhit.initFireAuth();

	rhit.startFirebase();
	
	rhit.fbAuthManager = new rhit.FbAuthManager();
	rhit.fbAuthManager.beginListening(() => {
		console.log("auth changed callback fired");
		console.log("isSignedIn = ", rhit.fbAuthManager.isSignedIn);

		const queryString = window.location.search;
		const urlParams = new URLSearchParams(queryString);
	
		if (document.querySelector("#loginPage") && rhit.fbAuthManager.isSignedIn) {
			window.location.href = "/list.html"
		}
		if (!document.querySelector("#loginPage") && !rhit.fbAuthManager.isSignedIn) {
			window.location.href = "/";
		}

		console.log("Ready");
		if(document.querySelector("#listPage")){
			console.log("You are on the list page.");
			const uid = urlParams.get("uid");
			console.log('got uid: ', uid);
			rhit.fbPhotosManager = new rhit.FbPhotosManager(uid);
			new rhit.ListPageController();
		}

		if(document.querySelector("#detailPage")){
			console.log("You are on the detail page.");
			const queryString = window.location.search;
			const urlParams = new URLSearchParams(queryString);
			const photoId = urlParams.get("id");
			console.log(`Page for ${photoId}`);
			if(!photoId){
				window.location.href = "/";
			}
			rhit.fbSinglePhotoManager = new rhit.FbSinglePhotoManager(photoId);
			new rhit.DetailPageController();
		}

		if (document.querySelector("#loginPage")) {
			console.log("You are on the login page.");
			new rhit.LoginPageController();
		}
	});
};

rhit.main();
