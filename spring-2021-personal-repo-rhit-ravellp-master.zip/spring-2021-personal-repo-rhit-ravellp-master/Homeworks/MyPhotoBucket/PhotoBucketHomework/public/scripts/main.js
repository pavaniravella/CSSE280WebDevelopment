//Pavani Ravella

var rhit = rhit || {};

rhit.FB_COLLECTION_PHOTOS = "Photos";
rhit.FB_KEY_IMAGEURL = "imageURL";
rhit.FB_KEY_CAPTION = "caption";
rhit.FB_KEY_LAST_TOUCHED = "lastTouched"
rhit.fbPhotosManager = null;
rhit.fbPhotoManager = null;


function htmlToElement(html) {
	var template = document.createElement('template');
	html = html.trim();
	template.innerHTML = html;
	return template.content.firstChild;
}
rhit.ListPageController = class {
	constructor() {
		document.querySelector("#submitAddPhoto").onclick = (event) => {
			const image = document.querySelector("#inputImage").value;
			const caption = document.querySelector("#inputCaption").value;
			if(!image || !caption){
				alert("Photo could not be added. Please enter an image url and caption.");
			} else {
				rhit.fbPhotosManager.add(image, caption);
			}
		};
		$('#addPhotoDialog').on('show.bs.modal', (event) => {
			document.querySelector("#inputImage").value = "";
			document.querySelector("#inputCaption").value = "";
		});
		$('#addPhotoDialog').on('shown.bs.modal', (event) => {
			document.querySelector("#inputImage").focus();
		});
		rhit.fbPhotosManager.beginListening(this.updateList.bind(this));
	}
	_createCard(photo){
		return htmlToElement(`<div class="pin" id="${photo.id}"><img
		src="${photo.image}"
		alt="${photo.caption}">
	  	<p class="caption">${photo.caption}</p>
		</div>`);
	}
	updateList(){
		const newList = htmlToElement('<div id="columns"></div>');
		for(let i = 0; i < rhit.fbPhotosManager.length; i++){
			const photo = rhit.fbPhotosManager.getPhotoAtIndex(i);
			const newCard = this._createCard(photo);
			newCard.onclick = (event) => {
				console.log(`You clicked on ${photo.id}`);
				window.location.href = `/photo.html?id=${photo.id}`;
			};
			newList.appendChild(newCard);
		}
		const oldList = document.querySelector("#columns");
		oldList.removeAttribute("id");
		oldList.hidden = true;
		oldList.parentElement.appendChild(newList);
	}
}
rhit.Photo = class {
	constructor(id, image, caption) {
		this.id = id;
		this.image = image;
		this.caption = caption;
	}
}
rhit.FbPhotosManager = class {
	constructor() {
		this._documentSnapshots = [];
		this._ref = firebase.firestore().collection(rhit.FB_COLLECTION_PHOTOS);
		this._unsubscribe = null;
	}
	add(image, caption){
		this._ref.add({
			[rhit.FB_KEY_IMAGEURL]: image,
			[rhit.FB_KEY_CAPTION]: caption,
			[rhit.FB_KEY_LAST_TOUCHED]: firebase.firestore.Timestamp.now()
		}).catch((error) => {
			console.error("Error adding document: ", error);
		});
	}
	beginListening(changeListener){
		this._unsubscribe = this._ref.onSnapshot((querySnapshot) => {
			this._documentSnapshots = querySnapshot.docs;
			changeListener();
		});
	}
	get length(){
		return this._documentSnapshots.length;
	}
	getPhotoAtIndex(index){
		const docSnapshot = this._documentSnapshots[index];
		const photo = new rhit.Photo(
			docSnapshot.id,
			docSnapshot.get(rhit.FB_KEY_IMAGEURL),
			docSnapshot.get(rhit.FB_KEY_CAPTION)
		);
		return photo;
	}
}
rhit.PhotoPageController = class {
	constructor() {
		document.querySelector("#submitEditPhoto").onclick = (event) => {
			const caption = document.querySelector("#inputCaption").value;
			rhit.fbPhotoManager.update(document.querySelector("#cardImage").src, caption);
		};
		$('#editPhotoDialog').on('show.bs.modal', (event) => {
			document.querySelector("#inputCaption").value = rhit.fbPhotoManager.caption;
		});
		$('#editPhotoDialog').on('shown.bs.modal', (event) => {
			document.querySelector("#inputCaption").focus();
		});
		document.querySelector("#submitDeletePhoto").onclick = (event) => {
			rhit.fbPhotoManager.delete().then(() => {
				console.log("Document deleted");
				window.location.href = "/";
			}).catch((error) => {
				console.error("Error removing document: ", error);
			});
		}

		rhit.fbPhotoManager.beginListening(this.updateView.bind(this));
	}
	updateView() {
		console.log("Update the view");
		document.querySelector("#cardImage").src = rhit.fbPhotoManager.image;
		document.querySelector("#cardImage").alt = rhit.fbPhotoManager.caption;
		document.querySelector("#cardCaption").innerHTML = rhit.fbPhotoManager.caption;
	}
}
rhit.FbPhotoManager = class {
	constructor(photoId) {
		this._documentSnapshot = {};
		this._unsubscribe = null;
		this._ref = firebase.firestore().collection(rhit.FB_COLLECTION_PHOTOS).doc(photoId);
	}
	beginListening(changeListener){
		this._unsubscribe = this._ref.onSnapshot((doc) => {
			if(doc.exists){
        		console.log("Current data: ", doc.data());
				this._documentSnapshot = doc;
				changeListener();
			} else {
				console.log("No such document!");
			}
		});
	}
	update(image, caption){
		this._ref.update({
			[rhit.FB_KEY_IMAGEURL]: image,
			[rhit.FB_KEY_CAPTION]: caption,
			[rhit.FB_KEY_LAST_TOUCHED]: firebase.firestore.Timestamp.now()
		})
		.catch((error) => {
			// The document probably doesn't exist.
			console.error("Error updating document: ", error);
		});
	}
	delete() {
		return this._ref.delete();
	}
	get image(){
		return this._documentSnapshot.get(rhit.FB_KEY_IMAGEURL);
	}
	get caption(){
		return this._documentSnapshot.get(rhit.FB_KEY_CAPTION);
	}
}

rhit.main = function () {
	console.log("Ready");
	if(document.querySelector("#listPage")){
		console.log("List page");
		rhit.fbPhotosManager = new rhit.FbPhotosManager();
		new rhit.ListPageController();
	}
	if(document.querySelector("#photoPage")){
		console.log("Photo page");
		const queryString = window.location.search;
		console.log(queryString);
		const urlParams = new URLSearchParams(queryString);
		const photoId = urlParams.get("id");
		console.log(`Photo page for ${photoId}`);
		if(!photoId){
			console.log("Error! Missing photo id!");
			window.location.href = "/";
		}
		rhit.fbPhotoManager = new rhit.FbPhotoManager(photoId);
		new rhit.PhotoPageController();
	}
};

rhit.main();
