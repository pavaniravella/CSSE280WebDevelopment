For each homework you should:
1. create a folder with the name of the homework (i.e. "FavoriteThings" )
2. copy the code from the public template repo or other homework specific template (may need to clone first to have a local version to copy)
3. commit your work as you make progress
4. Be sure to leave a commit message when the project is done, i.e. "FavoriteThings COMPLETE"